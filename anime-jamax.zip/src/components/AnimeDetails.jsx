
import React, { useEffect, useState } from 'react';
import VideoPlayer from './VideoPlayer';

const AnimeDetails = ({ animeId }) => {
  const [anime, setAnime] = useState(null);
  const [episodes, setEpisodes] = useState([]);
  const [selectedEpisode, setSelectedEpisode] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null);

  useEffect(() => {
    const fetchAnime = async () => {
      const res = await fetch(`https://api.consumet.org/anime/gogoanime/info/${animeId}`);
      const data = await res.json();
      setAnime(data);
      setEpisodes(data.episodes.reverse());
    };
    fetchAnime();
  }, [animeId]);

  useEffect(() => {
    const fetchEpisode = async () => {
      if (!selectedEpisode) return;
      const res = await fetch(`https://api.consumet.org/anime/gogoanime/watch/${selectedEpisode.id}`);
      const data = await res.json();
      setVideoUrl(data.sources[0]?.url);
    };
    fetchEpisode();
  }, [selectedEpisode]);

  return (
    <div className="p-4 bg-white rounded shadow">
      {anime ? (
        <>
          <h2 className="text-2xl font-bold mb-2">{anime.title}</h2>
          <img src={anime.image} alt={anime.title} className="w-48 mb-4 rounded-xl" />
          <p className="mb-4 text-gray-700">{anime.description}</p>

          {videoUrl && <VideoPlayer videoUrl={videoUrl} />}

          <h3 className="text-xl font-semibold mb-2">Épisodes :</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {episodes.map((ep) => (
              <button
                key={ep.id}
                className="bg-indigo-600 text-white p-2 rounded hover:bg-indigo-700"
                onClick={() => setSelectedEpisode(ep)}
              >
                Episode {ep.number}
              </button>
            ))}
          </div>
        </>
      ) : (
        <p>Chargement de l'anime...</p>
      )}
    </div>
  );
};

export default AnimeDetails;

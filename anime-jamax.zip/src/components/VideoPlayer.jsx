
import React from 'react';

const VideoPlayer = ({ videoUrl }) => {
  return (
    <div className="mb-6">
      <video controls className="w-full rounded-xl shadow-lg">
        <source src={videoUrl} type="video/mp4" />
        Votre navigateur ne supporte pas la vidéo.
      </video>
    </div>
  );
};

export default VideoPlayer;

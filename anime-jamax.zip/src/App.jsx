
import React from 'react';
import AnimeDetails from './components/AnimeDetails';

const App = () => {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <h1 className="text-3xl font-bold text-center text-indigo-600 mb-6">Anime-Jamax</h1>
      <AnimeDetails animeId="naruto-shippuden" />
    </div>
  );
};

export default App;
